import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-karen',
  templateUrl: './karen.component.html',
  styleUrls: ['./karen.component.scss']
})
export class KarenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
