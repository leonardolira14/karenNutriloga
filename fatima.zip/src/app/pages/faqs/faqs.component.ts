import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.scss']
})
export class FaqsComponent implements OnInit {
  p1 = true;
  p2 = true;
  p3 = true;
  p4 = true;
  p5 = true;
  p6 = true;
  p7 = true;
  p8 = true;
  p9 = true;
  p10 = true;
  p11 = true;
  p12= true;
  p13 = true;
  p14= true;
  p15 = true;
  p16 = true;
  p17 = true;
  p18 = true;
  constructor() { }

  ngOnInit(): void {
  }

}
