export const environment = {
  production: true,
  url_serve: 'https://nutriologakaren.com/karen_server/'
};
